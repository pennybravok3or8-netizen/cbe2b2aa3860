# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(gcc-trunk src/gcc-trunk.cpp)
set_property(TARGET gcc-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-trunk lionss pthread)

add_executable(flake-detector src/flake-detector.cpp)
set_property(TARGET flake-detector PROPERTY CXX_STANDARD 11)
target_link_libraries(flake-detector lionss pthread)

add_executable(decoder-fuzz src/decoder-fuzz.cpp)
set_property(TARGET decoder-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(decoder-fuzz lionss pthread)

add_executable(vectorization-report src/vectorization-report.cpp)
set_property(TARGET vectorization-report PROPERTY CXX_STANDARD 11)
target_link_libraries(vectorization-report lionss pthread)

add_executable(watchos-build src/watchos-build.cpp)
set_property(TARGET watchos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(watchos-build lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(cosign-verify src/cosign-verify.cpp)
set_property(TARGET cosign-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(cosign-verify lionss pthread)

add_executable(constexpr-tests src/constexpr-tests.cpp)
set_property(TARGET constexpr-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(constexpr-tests lionss pthread)

add_executable(sccache-stats src/sccache-stats.cpp)
set_property(TARGET sccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(sccache-stats lionss pthread)

add_executable(license-audit src/license-audit.cpp)
set_property(TARGET license-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(license-audit lionss pthread)

add_executable(aur-package src/aur-package.cpp)
set_property(TARGET aur-package PROPERTY CXX_STANDARD 11)
target_link_libraries(aur-package lionss pthread)

add_executable(pvs-studio src/pvs-studio.cpp)
set_property(TARGET pvs-studio PROPERTY CXX_STANDARD 11)
target_link_libraries(pvs-studio lionss pthread)

add_executable(uclibc-build src/uclibc-build.cpp)
set_property(TARGET uclibc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(uclibc-build lionss pthread)

add_executable(format-diff src/format-diff.cpp)
set_property(TARGET format-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(format-diff lionss pthread)

add_executable(license-headers src/license-headers.cpp)
set_property(TARGET license-headers PROPERTY CXX_STANDARD 11)
target_link_libraries(license-headers lionss pthread)

add_executable(homebrew-formula src/homebrew-formula.cpp)
set_property(TARGET homebrew-formula PROPERTY CXX_STANDARD 11)
target_link_libraries(homebrew-formula lionss pthread)

add_executable(false-sharing src/false-sharing.cpp)
set_property(TARGET false-sharing PROPERTY CXX_STANDARD 11)
target_link_libraries(false-sharing lionss pthread)

add_executable(linux-x86-64 src/linux-x86-64.cpp)
set_property(TARGET linux-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-x86-64 lionss pthread)

add_executable(cross-toolchain src/cross-toolchain.cpp)
set_property(TARGET cross-toolchain PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-toolchain lionss pthread)

add_executable(fuzz-corpus src/fuzz-corpus.cpp)
set_property(TARGET fuzz-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-corpus lionss pthread)

add_executable(weekly-build src/weekly-build.cpp)
set_property(TARGET weekly-build PROPERTY CXX_STANDARD 11)
target_link_libraries(weekly-build lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(canary-build src/canary-build.cpp)
set_property(TARGET canary-build PROPERTY CXX_STANDARD 11)
target_link_libraries(canary-build lionss pthread)

add_executable(coverage-guided-fuzz src/coverage-guided-fuzz.cpp)
set_property(TARGET coverage-guided-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-guided-fuzz lionss pthread)

add_executable(cve-check src/cve-check.cpp)
set_property(TARGET cve-check PROPERTY CXX_STANDARD 11)
target_link_libraries(cve-check lionss pthread)

add_executable(build-debug src/build-debug.cpp)
set_property(TARGET build-debug PROPERTY CXX_STANDARD 11)
target_link_libraries(build-debug lionss pthread)

add_executable(nanobench src/nanobench.cpp)
set_property(TARGET nanobench PROPERTY CXX_STANDARD 11)
target_link_libraries(nanobench lionss pthread)

add_executable(gcc-libstdcxx src/gcc-libstdcxx.cpp)
set_property(TARGET gcc-libstdcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-libstdcxx lionss pthread)

add_executable(llvm-libcxx src/llvm-libcxx.cpp)
set_property(TARGET llvm-libcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-libcxx lionss pthread)

add_executable(grype-scan src/grype-scan.cpp)
set_property(TARGET grype-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(grype-scan lionss pthread)

