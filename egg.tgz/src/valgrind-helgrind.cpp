// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("valgrind helgrind\n", stdout);
  return lionss_run_workload("valgrind-helgrind");
}
