// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("vectorization report\n", stdout);
  return lionss_run_workload("vectorization-report");
}
