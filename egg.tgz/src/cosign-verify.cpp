// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cosign verify\n", stdout);
  return lionss_run_workload("cosign-verify");
}
